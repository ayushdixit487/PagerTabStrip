//
//  sideMenuVC.swift
//  Alritey
//
//  Created by MACBOOK on 19/12/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class SideMenuVC: UIViewController {

    let headers : [String] = ["Home","Services","Get It Done","Rate"]
    var isselect: Int = 0
    var images : [UIImage] = [#imageLiteral(resourceName: "ic_home"),#imageLiteral(resourceName: "services-icon-png-2294"),#imageLiteral(resourceName: "ic_class_black_18dp"),#imageLiteral(resourceName: "ic_star_rate_18pt")]
        @IBOutlet weak var tblView: UITableView!
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
        
            tblView.register(UINib(nibName: "TblVC", bundle: nil), forCellReuseIdentifier: "TblVC")
          //  self.setNavigationBar()
            tblView.reloadData()
            
            // Do any additional setup after loading the view.
           
            
        }
    
    
}


extension SideMenuVC: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return headers.count
    }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TblVC", for: indexPath) as! TblVC
        cell.lblOption.text = headers[indexPath.row]
        cell.imgvw.image = images[indexPath.row]
        let bgColorView = UIView()
        bgColorView.backgroundColor = UIColor.green
        if indexPath.row == isselect{
            cell.selectedBackgroundView = bgColorView }
        let screenSize: CGRect = UIScreen.main.bounds
        let navBar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 48))
        let navItem = UINavigationItem(title: "MENU")
        
        navBar.setItems([navItem], animated: false)
       // tblView.addSubview(navBar)
        return cell
    }
        
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        if indexPath.row == isselect{
           // tblView.endEditing(true)
            
            toggleSideMenuView()
            return
        }
        
        isselect = indexPath.row
        switch indexPath.row {
        case 0:
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController1")
            sideMenuController()?.setContentViewController(secondVC!)
        case 1:
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController2")
            sideMenuController()?.setContentViewController(secondVC!)
        case 2:
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController3")
            sideMenuController()?.setContentViewController(secondVC!)
        case 3:
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController4")
            sideMenuController()?.setContentViewController(secondVC!)
    
        default:
            print("error")
        }
        tblView.reloadData()
    }
}
