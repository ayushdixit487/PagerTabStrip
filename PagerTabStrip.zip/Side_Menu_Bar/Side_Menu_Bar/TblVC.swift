//
//  TblVC.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 02/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class TblVC: UITableViewCell {

   
        
    @IBOutlet weak var imgvw: UIImageView!
    @IBOutlet weak var lblOption: UILabel!
    
        override func awakeFromNib() {
            super.awakeFromNib()
            // Initialization code
        }
    
        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
            
            // Configure the view for the selected state
        }    
}
