//
//  ViewController.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 02/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ViewController: HeaderVC{    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var vw1: UIView!
    @IBOutlet weak var Menubtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let navVC = self.navigationController as! navController
        navVC.reloadMenuView(self)
        
        self.sideMenuController()?.sideMenu?.delegate = self
        self.sideMenuController()?.sideMenu?.allowLeftSwipe = true
        self.sideMenuController()?.sideMenu?.allowPanGesture = true
        self.sideMenuController()?.sideMenu?.allowRightSwipe = true
        
        
        self.setNavigationBar()
        btnBack.addTarget(self, action: #selector(btnBack(_Sender:)), for: .touchUpInside)
    }    
    
    override func viewDidAppear(_ animated: Bool) {
        self.sideMenuController()?.sideMenu?.delegate = self
        self.sideMenuController()?.sideMenu?.allowLeftSwipe = true
        self.sideMenuController()?.sideMenu?.allowPanGesture = true
        self.sideMenuController()?.sideMenu?.allowRightSwipe = true
    }
    
    
    func setNavigationBar() {
        let screenSize: CGRect = UIScreen.main.bounds
        let navBar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 48))
        let navItem = UINavigationItem(title: "WELCOME")
               let button = UIButton(type: .custom)
        //set image for button
        button.setImage(UIImage(named : "ic_menu"), for: [])
        
        button.addTarget(self, action: #selector(btnaction(_:)), for: .touchUpInside)
        
        button.frame = CGRect(x: 0, y: 0, width: 53, height:31)
        
        let barButton = UIBarButtonItem(customView: button)
                navItem.rightBarButtonItem = barButton
        navBar.setItems([navItem], animated: false)
        self.view.addSubview(navBar)
    }
    func btnBack(_Sender: Any){
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController2") as! ViewController2
        secondVC.dontShow = true
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
    

  }

