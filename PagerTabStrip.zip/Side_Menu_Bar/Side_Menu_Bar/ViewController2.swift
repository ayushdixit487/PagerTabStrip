//
//  ViewController2.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 02/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit
import XLPagerTabStrip

class ViewController2: HeaderVC,IndicatorInfoProvider {
   
    var itemInfo = IndicatorInfo(title: "My Child title")
    var dontShow = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let backBtn = UIButton(frame: CGRect(x: 8, y: 48, width: 56, height: 56))
        backBtn.setImage(#imageLiteral(resourceName: "ic_keyboard_arrow_left"), for: .normal)
        backBtn.addTarget(self, action: #selector(btnActBack(_:)), for: .touchUpInside)
        let nextBtn = UIButton(frame: CGRect(x: 359, y: 48, width: 56, height: 56))
        nextBtn.setImage(#imageLiteral(resourceName: "ic_keyboard_arrow_right"), for: .normal)
        nextBtn.addTarget(self, action: #selector(btnNext(_Sender:)), for: .touchUpInside)
        self.view.addSubview(backBtn)
        self.view.addSubview(nextBtn)
        if dontShow{
            self.sideMenuController()?.sideMenu?.allowLeftSwipe = false
            self.sideMenuController()?.sideMenu?.allowPanGesture = false
            self.sideMenuController()?.sideMenu?.allowRightSwipe = false
            
        }else{
            self.setNavigationBar() 
        }
               // Do any additional setup after loading the view.
    }

    func setNavigationBar() {
        let screenSize: CGRect = UIScreen.main.bounds
        let navBar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 48))
        let navItem = UINavigationItem(title: "Services")
        let doneItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: nil, action: #selector(btnaction(_:)))
        navItem.rightBarButtonItem = doneItem
        navBar.setItems([navItem], animated: false)
       self.view.addSubview(navBar)
    }
   
    func btnActBack(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    func btnNext(_Sender: Any){
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController3") as! ViewController3
        secondVC.dontShow = true
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return itemInfo
    }

}
