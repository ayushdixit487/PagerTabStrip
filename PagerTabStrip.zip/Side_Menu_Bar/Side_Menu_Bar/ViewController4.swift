//
//  ViewController4.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 03/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

import XLPagerTabStrip

class ViewController4: HeaderVC,IndicatorInfoProvider {
    
    var itemInfo = IndicatorInfo(title: "My Child title")

     var dontShow = false
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.setNavigationBar()
        let backBtn = UIButton(frame: CGRect(x: 8, y: 48, width: 56, height: 56))
        backBtn.setImage(#imageLiteral(resourceName: "ic_keyboard_arrow_left"), for: .normal)
        backBtn.addTarget(self, action: #selector(btnActBack(_:)), for: .touchUpInside)
        // Do any additional setup after loading the view.
        self.view.addSubview(backBtn)
        if dontShow{
            self.sideMenuController()?.sideMenu?.allowLeftSwipe = false
            self.sideMenuController()?.sideMenu?.allowPanGesture = false
            self.sideMenuController()?.sideMenu?.allowRightSwipe = false
            
        }else{
            self.setNavigationBar() 
        }

    }
    
    func setNavigationBar() {
        let screenSize: CGRect = UIScreen.main.bounds
        let navBar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 48))
        let navItem = UINavigationItem(title: "Rate")
        let doneItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: nil, action: #selector(btnaction(_:)))
        navItem.rightBarButtonItem = doneItem
        navBar.setItems([navItem], animated: false)
        self.view.addSubview(navBar)
       
    }
    func btnActBack(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return itemInfo
    }

   
}
