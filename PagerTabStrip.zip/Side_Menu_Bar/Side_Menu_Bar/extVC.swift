//
//  extVC.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 05/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class extVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "connectInternal"{
            _ = segue.destination as! tabBarVC
            
        }
        
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }

}
