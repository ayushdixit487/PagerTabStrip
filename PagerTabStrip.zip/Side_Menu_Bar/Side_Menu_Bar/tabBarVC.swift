//
//  tabBarVC.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 05/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit
import XLPagerTabStrip


class tabBarVC: ButtonBarPagerTabStripViewController {

    var isReload = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetting()
        // Do any additional setup after loading the view.
    }
    
    func initialSetting(){
        
        // setting selectoin view
        // customizations colors
        
        buttonBarView.collectionViewLayout = UICollectionViewFlowLayout()
        
        buttonBarView.backgroundColor = UIColor.green 
        buttonBarView.selectedBar.backgroundColor = UIColor.white
        settings.style.buttonBarItemBackgroundColor = UIColor.clear
        settings.style.selectedBarHeight = 1
        
        // fonts and width of selection view
        settings.style.buttonBarItemFont = UIFont.boldSystemFont(ofSize: 15)         
        changeCurrentIndexProgressive = { (oldCell: ButtonBarViewCell?, newCell: ButtonBarViewCell?, progressPercentage: CGFloat, changeCurrentIndex: Bool, animated: Bool) -> Void in
            guard changeCurrentIndex == true else { return }
            
            oldCell?.label.textColor = UIColor(white: 1, alpha: 0.8)
            newCell?.label.textColor = UIColor.white
            
        }
        self.viewDidLayoutSubviews()
    }
    
    // MARK: - PagerTabStripDataSource
    override func viewControllers(for pagerTabStripController: PagerTabStripViewController) -> [UIViewController] {
        
        // setting view controller of new lead view
    //    let HomeVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController1") as! ViewController
        //self.navigationController?.pushViewController(HomeVC, animated: true)
        //HomeVC.itemInfo = IndicatorInfo(title: "Home")
      //  let child_1 = HomeVC
        let earnedVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController2") as! ViewController2
        self.navigationController?.pushViewController(earnedVC, animated: true)
        earnedVC.itemInfo = IndicatorInfo(title: "Services")
        let child_2 = earnedVC

//      
        let paidVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController3") as! ViewController3
        self.navigationController?.pushViewController(paidVC, animated: true)
        paidVC.itemInfo = IndicatorInfo(title: "Get It Done")
        let child_3 = paidVC
              let RateVC = self.storyboard?.instantiateViewController(withIdentifier: "viewController4") as! ViewController4
        self.navigationController?.pushViewController(RateVC, animated: true)
        RateVC.itemInfo = IndicatorInfo(title: "Rate")  
        let child_4 = RateVC
        guard isReload else {
            return [child_2,child_3,child_4]
        }
        
        var childViewControllers = [child_2,child_3,child_4]
        
        for (index, _) in childViewControllers.enumerated(){
            let nElements = childViewControllers.count - index
            let n = (Int(arc4random()) % nElements) + index
            if n != index{
                swap(&childViewControllers[index], &childViewControllers[n])
            }
        }
        
        let nItems = 1 + (arc4random() % 2)
        return Array(childViewControllers.prefix(Int(nItems)))
    }

}
